//
//  StockObserver.h
//  Observer
//
//  Created by hukaiyin on 16/3/12.
//  Copyright © 2016年 HKY. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "Observer.h"

@interface StockObserver : Observer

@end

@interface NBAObserver : Observer

@end
