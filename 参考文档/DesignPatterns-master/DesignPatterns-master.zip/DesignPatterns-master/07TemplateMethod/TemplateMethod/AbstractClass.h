//
//  AbstractClass.h
//  TemplateMethod
//
//  Created by HKY on 16/2/24.
//  Copyright © 2016年 HKY. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface AbstractClass : NSObject

- (void)primitiveOperation1;
- (void)primitiveOperation2;
- (void)templateMethod;

@end
