//
//  ConcreteClassB.m
//  TemplateMethod
//
//  Created by HKY on 16/2/24.
//  Copyright © 2016年 HKY. All rights reserved.
//

#import "ConcreteClassB.h"

@implementation ConcreteClassB

- (void)primitiveOperation1 {
    NSLog(@"具体类 B 方法1实现");
}

- (void)primitiveOperation2 {
    NSLog(@"具体类 B 方法2实现");
}

@end
