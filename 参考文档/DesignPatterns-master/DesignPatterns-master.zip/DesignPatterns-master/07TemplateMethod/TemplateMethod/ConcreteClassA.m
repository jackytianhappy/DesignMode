//
//  ConcreteClass.m
//  TemplateMethod
//
//  Created by HKY on 16/2/24.
//  Copyright © 2016年 HKY. All rights reserved.
//

#import "ConcreteClassA.h"

@implementation ConcreteClassA

- (void)primitiveOperation1 {
    NSLog(@"具体类 A 方法1实现");
}

- (void)primitiveOperation2 {
    NSLog(@"具体类 A 方法2实现");
}

@end
