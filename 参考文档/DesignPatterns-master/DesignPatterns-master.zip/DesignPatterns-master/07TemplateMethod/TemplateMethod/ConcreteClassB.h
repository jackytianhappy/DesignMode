//
//  ConcreteClassB.h
//  TemplateMethod
//
//  Created by HKY on 16/2/24.
//  Copyright © 2016年 HKY. All rights reserved.
//

#import "AbstractClass.h"

@interface ConcreteClassB : AbstractClass

@end
