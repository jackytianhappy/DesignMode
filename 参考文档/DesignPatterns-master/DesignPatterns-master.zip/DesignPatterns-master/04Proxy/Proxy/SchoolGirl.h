//
//  SchoolGirl.h
//  Proxy
//
//  Created by 56QQ on 16/2/17.
//  Copyright © 2016年 HKY. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface SchoolGirl : NSObject
@property (nonatomic,strong)NSString *name;
@end
