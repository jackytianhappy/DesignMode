//
//  Component.m
//  Decorator
//
//  Created by HKY on 16/2/16.
//  Copyright © 2016年 HKY. All rights reserved.
//

#import "Component.h"

@implementation Component

- (void)operation {
    
}

@end
