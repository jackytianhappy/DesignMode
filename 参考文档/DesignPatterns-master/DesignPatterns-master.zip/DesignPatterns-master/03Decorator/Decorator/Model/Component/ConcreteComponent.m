//
//  ConcreteComponent.m
//  Decorator
//
//  Created by HKY on 16/2/16.
//  Copyright © 2016年 HKY. All rights reserved.
//

#import "ConcreteComponent.h"

@implementation ConcreteComponent

- (void)operation {
    NSLog(@"具体对象的操作");
}

@end
