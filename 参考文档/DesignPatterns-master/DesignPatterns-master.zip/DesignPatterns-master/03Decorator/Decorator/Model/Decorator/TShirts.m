//
//  TShirts.m
//  Decorator
//
//  Created by HKY on 16/2/17.
//  Copyright © 2016年 HKY. All rights reserved.
//

#import "TShirts.h"

@implementation TShirts

- (void)show {
    [super show];
    NSLog(@"T 恤");
}

@end
