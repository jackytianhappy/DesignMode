//
//  BigTrouser.m
//  Decorator
//
//  Created by HKY on 16/2/17.
//  Copyright © 2016年 HKY. All rights reserved.
//

#import "BigTrouser.h"

@implementation BigTrouser

- (void)show {
    [super show];
    NSLog(@"垮裤");
}

@end
