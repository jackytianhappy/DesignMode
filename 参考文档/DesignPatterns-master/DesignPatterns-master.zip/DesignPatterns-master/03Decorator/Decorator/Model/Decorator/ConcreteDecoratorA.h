//
//  ConcreteDecoratorA.h
//  Decorator
//
//  Created by HKY on 16/2/17.
//  Copyright © 2016年 HKY. All rights reserved.
//

#import "Decorator.h"

@interface ConcreteDecoratorA : Decorator

@end
