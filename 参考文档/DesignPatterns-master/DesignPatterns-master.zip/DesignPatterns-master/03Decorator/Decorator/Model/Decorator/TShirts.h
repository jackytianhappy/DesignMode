//
//  TShirts.h
//  Decorator
//
//  Created by HKY on 16/2/17.
//  Copyright © 2016年 HKY. All rights reserved.
//

#import "Finery.h"

@interface TShirts : Finery

@end
