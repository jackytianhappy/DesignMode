//
//  SystemOne.h
//  Facade
//
//  Created by HKY on 16/2/24.
//  Copyright © 2016年 HKY. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface SystemOne : NSObject

- (void)methodOne;

@end
