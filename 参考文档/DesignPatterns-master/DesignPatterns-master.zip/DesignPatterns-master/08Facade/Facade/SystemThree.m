//
//  SystemThree.m
//  Facade
//
//  Created by HKY on 16/2/24.
//  Copyright © 2016年 HKY. All rights reserved.
//

#import "SystemThree.h"

@implementation SystemThree

- (void)methodThree {
    NSLog(@"\nSystemThree methodThree");
}
@end
