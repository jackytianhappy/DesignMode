//
//  SystemOne.m
//  Facade
//
//  Created by HKY on 16/2/24.
//  Copyright © 2016年 HKY. All rights reserved.
//

#import "SystemOne.h"

@implementation SystemOne

- (void)methodOne {
    NSLog(@"\nSystemOne methodOne");
}

@end
