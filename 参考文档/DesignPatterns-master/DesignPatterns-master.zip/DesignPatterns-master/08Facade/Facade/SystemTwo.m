//
//  SystemTwo.m
//  Facade
//
//  Created by HKY on 16/2/24.
//  Copyright © 2016年 HKY. All rights reserved.
//

#import "SystemTwo.h"

@implementation SystemTwo

- (void)methodTwo {
    NSLog(@"\nSystemTwo methodTwo");
}
@end
