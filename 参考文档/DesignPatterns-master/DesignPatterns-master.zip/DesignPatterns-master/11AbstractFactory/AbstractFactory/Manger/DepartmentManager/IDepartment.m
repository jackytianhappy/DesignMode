//
//  IDpartment.m
//  AbstractFactory
//
//  Created by hukaiyin on 16/3/15.
//  Copyright © 2016年 HKY. All rights reserved.
//

#import "IDepartment.h"

@implementation IDepartment

- (void)instertIDpartment:(Department *)department {
    
}

- (void)getIDpartmentWithId:(NSInteger)departmentId {
    
}

@end
