//
//  LeiFeng.m
//  FactoryMethod
//
//  Created by 56QQ on 16/2/18.
//  Copyright © 2016年 test. All rights reserved.
//

#import "LeiFeng.h"

@implementation LeiFeng

- (void)sweep {
    NSLog(@"扫地");
}

- (void)wash {
    NSLog(@"洗衣服");
}

- (void)buyRice {
    NSLog(@"买米");
}

@end
