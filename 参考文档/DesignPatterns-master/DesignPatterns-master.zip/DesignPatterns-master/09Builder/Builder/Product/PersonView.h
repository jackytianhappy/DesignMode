//
//  PersonView.h
//  Builder
//
//  Created by HKY on 16/2/24.
//  Copyright © 2016年 HKY. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface PersonView : UIView

@property (nonatomic ,assign) CGFloat headRadius;
@property (nonatomic ,assign) CGFloat bodyWidthSale;
@property (nonatomic ,assign) CGFloat bodyHeightSale;

@end
